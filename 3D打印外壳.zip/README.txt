                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2993338
NodeMCU V3 with 0.96 inch OLED Display by jhummel is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This case is made for NodeMCU V3 and OLED 0.96 Display

https://youtu.be/ulPdvkD8mAw you can see this Display in action on youtube.

- NodeMCU V3 https://amzn.to/2J0QNlF
- OLED 0.96 128*64 pixel Display https://amzn.to/2KO6Gk9

<h3>ATTENTION for OLED Display:</h3>
Don't push or press the display into the case. It will destroy the OLED-Display.

All devices were fixed with a hot glue gun, especially the OLED display, as no pressure should be exerted on it.

For Feeds i used this 3M Bumpon:
- https://amzn.to/2IYWIrb


Remix of:
https://www.thingiverse.com/thing:2670123
https://www.thingiverse.com/thing:2176764

 

# Custom Section

<iframe src="//www.youtube.com/embed/ulPdvkD8mAw" frameborder="0" allowfullscreen></iframe>
OLED Display zur Anzeige von Benzinpreisen